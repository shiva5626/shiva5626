
from flask import Blueprint, jsonify, request
from .models import User, db
from flask_jwt_extended import jwt_required
from flasgger.utils import swag_from

main = Blueprint('main', __name__)

@main.route('/users', methods=['GET'])
@jwt_required()
@swag_from({
    'responses': {200: {'description': 'List users'}}
})
def get_users():
    users = User.query.all()
    return jsonify([{'id': u.id, 'username': u.username, 'email': u.email} for u in users])
